package edu.neu.coe.info6205.util;
import edu.neu.coe.info6205.sort.elementary.InsertionSort;
import java.util.Arrays;

public class InsorttimeTest {
    public static void main(String[] args) {

        int testnumber[] = new int[]{1000,4000,9000,16000,25000};
        for(int i=0;i<testnumber.length;i++){
            Comparable[] RandomA = new Comparable[testnumber[i]];
            InsertionSort Insert = new InsertionSort();
            for (int j = 0; j < RandomA.length; j++) {
                RandomA[j] = ((int) (Math.random() * testnumber[i]));
            }

            Comparable[] OrderA = new Comparable[testnumber[i]];
            for (int j = 0; j < RandomA.length; j++) {
                OrderA[j] = ((int) (Math.random() * testnumber[i]));
            }

            Arrays.sort(OrderA);

            Comparable[] PartiOrderA = new Comparable[testnumber[i]];
            for (int j = 0; j < OrderA.length / 2; j++) {
                PartiOrderA[j] = OrderA[j];
            }

            for (int j = RandomA.length / 2; j < OrderA.length; j++) {
                PartiOrderA[j] = RandomA[j];
            }
            Comparable[] ReverOrderA = new Comparable[testnumber[i]];
            for (int j = OrderA.length - 1; j >= 0; j--) {
                ReverOrderA[OrderA.length - j - 1] = OrderA[j];
            }

            Timer timer1 = new Timer();
            Timer timer2 = new Timer();
            Timer timer3 = new Timer();
            Timer timer4 = new Timer();
            final int zzz = 20;

            final double RandomT = timer1.repeat(20, () -> zzz, t -> {
                Insert.sort(RandomA, 0, RandomA.length - 1);
                return null;
            });
            System.out.println("The time of insertion sort of a random number group with length "+testnumber[i]+" is "+RandomT);
            final double OrderT = timer2.repeat(20, () -> zzz, t -> {
                Insert.sort(OrderA, 0, OrderA.length - 1);
                return null;
            });
            System.out.println("The time of insertion sort of an ordered array length "+testnumber[i]+" is "+OrderT);
            final double PartOrderT = timer3.repeat(20, () -> zzz, t -> {
                Insert.sort(PartiOrderA, 0, PartiOrderA.length - 1);
                return null;
            });
            System.out.println("The time of insertion sort of an partially-ordered array with length "+testnumber[i]+" is "+PartOrderT);
            final double ReverOrderT = timer4.repeat(20, () -> zzz, t -> {
                Insert.sort(ReverOrderA, 0, ReverOrderA.length - 1);
                return null;
            });
            System.out.println("The time of insertion sort of a reverse-ordered array with length "+testnumber[i]+" is "+ReverOrderT);

            System.out.println("---------------------------------------------------------------------------------------");

        }



    }

}
